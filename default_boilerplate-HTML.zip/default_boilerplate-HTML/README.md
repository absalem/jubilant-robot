boilerplate like a pro
===========

- Mobile-detect for RESS support
- Rich snippet searchAction, breadcrumb




![boilerplate lab](https://dl.dropboxusercontent.com/u/13322055/stuff/lab-beakers.gif "Boilerplate Lab")
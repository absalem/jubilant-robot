/*
 * app 1.0.0 by menadwork GmbH (http://www.menadwork.com) (2014-04-03, 08:50)
 */

$(document).ready(function(){});
//# sourceMappingURL=app.map